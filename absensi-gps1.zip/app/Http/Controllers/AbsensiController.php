<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Redirect;

class AbsensiController extends Controller
{
    public function create(){
        $hariini    = date("Y-m-d");
        $nik        = Auth::guard('karyawan')->user()->nik;
        $cek        = DB::table('absensi')->where('tgl_absensi', $hariini)->where('nik', $nik)->count();
        return view('absensi.create', compact('cek'));
    }

    public function store(Request $request){
        // $nik = Auth::guard('karyawan')->user()->nik;
        // $tgl_absensi = date("Y-m-d");
        // $jam = date("H:i:s");
        // $lokasi = $request->lokasi;
        // $image = $request->image;
        // $folderPath = "public/uploads/presensi/";
        // $formatName = $nik . "-" . $tgl_absensi;
        // $image_parts = explode(";base64", $image);
        // $image_base64 = base64_decode($image_parts[1]);
        // $fileName = $formatName . ".png";
        // $file = $folderPath . $fileName;


        $nik = Auth::guard('karyawan')->user()->nik;
        $tgl_absensi = date("Y-m-d");
        $jam = date("H:i:s");

        // script Lokasi Kantor
        $latitudekantor = -7.739844100369356;
        $longitudkantor = 110.46191618526666;
        // $latitudekantor = -7.5123401400230705;
        // $longitudkantor = 110.63880137513144;

        // script Lokasi user
        $lokasi = $request->lokasi;
        $lokasiuser = explode(",", $lokasi);
        $latitudeuser = $lokasiuser[0];
        $longituduser = $lokasiuser[1];
        $jarak = $this->distance($latitudekantor,$longitudkantor,$latitudeuser,$longituduser);
        $radius = round($jarak["meters"]);


        $cek = DB::table('absensi')->where('tgl_absensi', $tgl_absensi)->where('nik', $nik)->count();
        if($cek > 0){
            $ket = "keluar";
        } else {
            $ket = "masuk";
        }

        // script gambar foto
        $image = $request->image;
        $folderPath= "public/uploads/presensi/";
        $formatName = $nik . "-" . $tgl_absensi . "-" . $ket;
        $image_parts = explode(";base64", $image);
        $image_base64 = base64_decode($image_parts[1]);
        $fileName = $formatName . ".png";
        $file = $folderPath . $fileName;
        
       
        if ($radius > 50) {
            echo "error|Maaf Anda Berada Di Luar Radius, Jarak Anda ". $radius ." Meter dari kantor|radius";
        } else {
            if($cek > 0) {
                $data_pulang = [
                    'jam_pulang'     => $jam,
                    'foto_pulang'    => $fileName,
                    'lokasi_pulang'  => $lokasi
                ];
                $update = DB::table('absensi')->where('tgl_absensi', $tgl_absensi)->where('nik', $nik)->update($data_pulang);
                if ($update) {
                    echo "success|Terimakasih Hati hati Di Jalan|out";
                    Storage::put($file, $image_base64);
                } else {
                    echo "error|Maaf Gagal Absen Silahkan Hubungi Admin|out";
                }
            } else {
                $data_masuk = [
                    'nik'           => $nik,
                    'tgl_absensi'   => $tgl_absensi,
                    'jam_masuk'     => $jam,
                    'foto_masuk'    => $fileName,
                    'lokasi_masuk'  => $lokasi
                ];
                $simpan = DB::table('absensi')->insert($data_masuk);
                if ($simpan) {
                    echo "success|Terimakasih, Selamat Bekerja|in";
                    Storage::put($file, $image_base64);
                } else {
                    echo "error|Maaf Gagal Absen Silahkan Hubungi Admin|out";
                }
            }
        }    
    }

    //Menghitung Jarak
    function distance($lat1, $lon1, $lat2, $lon2)
    {
        $theta = $lon1 - $lon2;
        $miles = (sin(deg2rad($lat1)) * sin(deg2rad($lat2))) + (cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta)));
        $miles = acos($miles);
        $miles = rad2deg($miles);
        $miles = $miles * 60 * 1.1515;
        $feet = $miles * 5280;
        $yards = $feet / 3;
        $kilometers = $miles * 1.609344;
        $meters = $kilometers * 1000;
        return compact('meters');
    }
  

    public function editprofile()
    {
        $nik = Auth::guard('karyawan')->user()->nik;
        $karyawan = DB::table('karyawan')->where('nik', $nik)->first();
        return view('absensi.editprofile',compact('karyawan'));
    }

    public function updateprofile(Request $request)
    {
        $nik = Auth::guard('karyawan')->user()->nik;
        $nama_lengkap = $request->nama_lengkap;
        $no_hp = $request->no_hp;
        $jabatan = $request->jabatan;
        $foto = $request->foto;
        $password = Hash::make($request->password);
        $karyawan = DB::table('karyawan')->where('nik', $nik)->first();
        if ($request->hasFile('foto')) {
            $foto = $nik.".".$request->file('foto')->getClientOriginalExtension();
        } else {
            $foto = $karyawan->foto;
        }
        if (empty($request->password)) {
            $data = [
                'nama_lengkap'  => $nama_lengkap,
                'jabatan'       => $jabatan,
                'foto'         => $foto,
                'no_hp'         => $no_hp
                
            ];
        } else { 
            $data = [
                'nama_lengkap'  => $nama_lengkap,
                'jabatan'       => $jabatan,
                'no_hp'         => $no_hp,
                'foto'          => $foto,
                'password'      => $password
            ];
        }
        $update = DB::table('karyawan')->where('nik', $nik)->update($data);
        if($update){
            if($request->hasFile('foto')){
                $folderPath = "public/uploads/karyawan/";
                $request->file('foto')->storeAs($folderPath, $foto);
            }
            return Redirect::back()->with(['success' => 'Data Berhasil di Update']);
        } else {
            return Redirect::back()->with(['error' => 'Data Gagal di Update']);
        }
        
    }

    public function histori()
    {
        $namabulan = ["","Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember",];
        return view('absensi.histori',compact('namabulan'));   
    }

    public function gethistori(Request $request)
    {
        $bulan = $request->bulan;
        $tahun = $request->tahun;
        $nik = Auth::guard('karyawan')->user()->nik;

        $histori = DB::table('absensi')
        ->whereRaw('MONTH(tgl_absensi)="'.$bulan.'" ')
        ->whereRaw('YEAR(tgl_absensi)="'.$tahun.'"')
        ->where('nik', $nik)
        ->orderBy('tgl_absensi')
        ->get();

        return view('absensi.gethistori', compact('histori'));
    }

    public function izin()
    {
         return view('absensi.izin');   
    }

    public function buatizin()
    {
         return view('absensi.buatizin');   
    }

}
