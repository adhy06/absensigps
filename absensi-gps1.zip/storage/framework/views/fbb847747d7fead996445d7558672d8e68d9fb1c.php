<?php if($histori->isEmpty()): ?>
<div class="alert alert-outline-warning">
    <p>Tidak Ada Data</p>
</div>
    
<?php endif; ?>

<?php $__currentLoopData = $histori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<ul class="listview image-listview">
        <li>
            <div class="item">
                <?php
                    $path = Storage::url('uploads/presensi/'.$d->foto_masuk);   
                ?>
                <img src="<?php echo e(url($path)); ?>" alt="image" class="image">
                <div class="in">
                    <div>
                        <b><?php echo e(date("d-m-Y", strtotime($d->tgl_absensi))); ?></b>
                    </div>
                    <span class="badge <?php echo e($d->jam_masuk < "08:00" ? "bg-success" : "bg-danger"); ?> ">
                        <b><?php echo e($d->jam_masuk); ?></b>
                    </span>
                    <span class="badge bg-primary"><b><?php echo e($d->jam_masuk); ?></b>
                    </span>
                </div>
            </div>
        </li>

</ul>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\Aplikasi\Absensi Online\absensi-gps\resources\views/absensi/gethistori.blade.php ENDPATH**/ ?>