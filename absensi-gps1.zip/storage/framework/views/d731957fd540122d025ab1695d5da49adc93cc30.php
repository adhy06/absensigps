

<!-- Header -->
<?php $__env->startSection('header'); ?>
<div class="appHeader bg-primary text-light">
    <div class="left">
        <a href="javascript:;" class="headerButton goBack">
            <ion-icon name="chevron-back-outline"></ion-icon>
        </a>
    </div>
    <div class="pageTitle">Data Izin / Sakit</div>
    <div class="right"></div>
</div>
<?php $__env->stopSection(); ?>   
<!-- End Header -->

<!-- Content -->
<?php $__env->startSection('content'); ?>

<div class="fab-button bottom-right" style="margin-bottom: 70px">
<a href="/absensi/buatizin" class="fab"><ion-icon name="add-outline"></ion-icon></a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.absensi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Aplikasi\Absensi Online\absensi-gps\resources\views/absensi/izin.blade.php ENDPATH**/ ?>