

<!-- Header -->
<?php $__env->startSection('header'); ?>
<div class="appHeader bg-primary text-light">
    <div class="left">
        <a href="javascript:;" class="headerButton goBack">
            <ion-icon name="chevron-back-outline"></ion-icon>
        </a>
    </div>
    <div class="pageTitle">Buat Izin</div>
    <div class="right"></div>
</div>
<?php $__env->stopSection(); ?>   
<!-- End Header -->

<!-- Content -->
<?php $__env->startSection('content'); ?>

<div class="row" style="margin-top: 4rem">
    
</div>

<form action=" " method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="col">
        <div class="form-group boxed">
            <div class="input-wrapper">
                <input class="form-control datepicker" type="text" name="tgl_izin" placeholder="Tanggal Izin" data-date-format="mm/dd/yyyy"></div>
        </div>
        <div class="form-group boxed">
            <div class="input-wrapper">
                <input type="text" class="form-control" value="" name="jabatan" placeholder="Jabatan" autocomplete="off">
            </div>
        </div>
        <div class="form-group boxed">
            <div class="input-wrapper">
                <input type="text" class="form-control" value=" " name="no_hp" placeholder="No. HP" autocomplete="off">
            </div>
        </div>
        <div class="custom-file-upload" id="fileUpload1">
            <input type="file" name="foto" id="fileuploadInput" accept=".png, .jpg, .jpeg">
            <label for="fileuploadInput">
                <span>
                    <strong>
                        <ion-icon name="cloud-upload-outline" role="img" class="md hydrated" aria-label="cloud upload outline"></ion-icon>
                        <i>Upload Dokumen yang dibutuhkan</i>
                    </strong>
                </span>
            </label>
        </div>
        <div class="form-group boxed">
            <div class="input-wrapper">
                <button type="submit" class="btn btn-primary btn-block">
                    <ion-icon name="save-outline"></ion-icon>
                    Simpan
                </button>
            </div>
        </div>
    </div>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.absensi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Aplikasi\Absensi Online\absensi-gps\resources\views/absensi/buatizin.blade.php ENDPATH**/ ?>